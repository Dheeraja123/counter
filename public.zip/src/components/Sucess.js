import React from 'react'
const Sucess = (props) => {
    return (
        <div>
        <h1>Welcome <span>{props.name}</span></h1>
        </div>
    );
}

export default Sucess;