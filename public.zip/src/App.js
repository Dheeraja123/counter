import React from 'react';
import Login from './components/Login';
import Signup from './components/Signup';
import Sucess from './components/Sucess';
class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      quantity: 1,
      show: true,
      max: 1000,
      min: 0
    };
  }

  IncrementItem = () => {
	var  n =1;
      this.setState(prevState => {
		    console.log(prevState.quantity)
        if(prevState.quantity < this.state.max) {
          return {
            quantity: Number(prevState.quantity) + Number(n)
		
          }
        } else {
          return null;
        }
      });
  }
  DecreaseItem = () => {
    this.setState(prevState => {
      if(prevState.quantity > 0) {
        return {
          quantity: prevState.quantity - 1
        }
      } else {
        return null;
      }
    });
  }
  ToggleClick = () => {
    this.setState({
      show: !this.state.show
    });
  }
  handleChange = (event) => {
    this.setState({quantity: event.target.value});
  }

  render() {

    return ( <div>
	<div style={{textAlign: 'center',width: '141px',margin:'auto',marginTop:'300px'}}>
      <button style={{padding:'15px',color: 'white',backgroundColor: 'brown'}}className="plus" onClick={this.IncrementItem}>+</button>
      <input style={{ height:'57px',width: '45px',textAlign: 'center'}}className="inputne" value={this.state.quantity} onChange={this.handleChange}/>
      <button style={{padding:'15px',color: 'brown',backgroundColor: 'white'}} onClick = {this.DecreaseItem} className="minus">-< /button>
	  </div>
      </div>
    );
  }
}

export default App;


/*
constructor(props) {
  super(props);
  this.isPaid=false;
  this.state = { paid:this.isPaid };
}
free(){
  return(
    <h1>Free User</h1>
  )
}
paid(){
  return(
    <h1>Paid User</h1>
  )
}

render() {
  return (
    <>
    { this.isPaid?this.paid():this.free()}
    <button onClick={()=>{
     this.isPaid=!this.isPaid;
     this.setState({...this.state,paid:this.isPaid});
    }}>Click me</button>
    </>
  );
}
}*/